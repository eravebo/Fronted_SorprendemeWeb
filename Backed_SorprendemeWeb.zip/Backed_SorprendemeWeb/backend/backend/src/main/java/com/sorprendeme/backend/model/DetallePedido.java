package com.sorprendeme.backend.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "detalle_pedido")
public class DetallePedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // @JsonIgnore evita el bucle infinito al serializar Pedido -> detalles -> Pedido
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "pedido_id", nullable = false)
    private Pedido pedido;

    // @JsonIgnoreProperties permite recibir solo { id: 2 } sin necesitar
    // todos los campos del producto
    @JsonIgnoreProperties(ignoreUnknown = true)
    @ManyToOne
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;

    @Column(nullable = false)
    private Integer cantidad;

    // El campo se llama precioUnitario para coincidir con lo que envía el frontend
    @Column(nullable = false)
    private Double precioUnitario;
}